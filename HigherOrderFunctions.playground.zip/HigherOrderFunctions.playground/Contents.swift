import UIKit

var greeting = "Hello, playground"


let array = [1, 2, 3, 4, 5, 6]
print(array.vMap { $0 * 2 })

let compactmap = ["1", "2", "3", "4", "vinodh", "7", "kumar"]
print(compactmap.vCompactMap { Int($0) })

let flatmap = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(flatmap.vFlatMap { $0 })

let filter = ["1", "2", "3", "4", "vinodh", "7", "kumar"]
print(filter.vFilter { Int($0) != nil })
let filter2 = [1, 2, 3, 4, 5, 6]
print(filter2.vFilter { $0 % 2 == 1 })

let reduce = [1, 2, 3, 4, 5, 6]
print(reduce.vReduce(0, transorm: +))

extension Array {
    func vMap<T>(transform:(Element) -> T) -> [T] {
        var result: [T] = []
        forEach { element in
            result.append(transform(element))
        }
        return result
    }
    
    func vCompactMap<T>(trasnform:(Element) -> T?) -> [T] {
        var result: [T] = []
        forEach { element in
            if let value = trasnform(element) {
                result.append(value)
            }
        }
        return result
    }

    func vFlatMap<T>(transform:(Element) -> [T]) -> [T] {
        var result: [T] = []
        forEach { element in
            result.append(contentsOf: transform(element))
        }
        return result
    }

    func vFilter(transform:(Element) -> Bool) -> [Element] {
        var result: [Element] = []
        forEach { element in
            if transform(element) {
                result.append(element)
            }
        }
        return result
    }
    
    func vReduce<T>(_ inital: T, transorm:(T, Element) -> T) -> T {
        var result = inital
        forEach { element in
            result = transorm(result, element)
        }
        return result
    }
}
