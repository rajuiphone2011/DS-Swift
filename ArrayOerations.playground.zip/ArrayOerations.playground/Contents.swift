import UIKit

var str = "Hello, playground"

//MARK: Reverse an array or string

var array = [5, 3, 6, 7, 8]

var startIdx = 0
var endIdx = array.count-1

while startIdx<endIdx {
    array.swapAt(startIdx, endIdx)

//    let startValue = array[startIdx]
//    let endValue = array[endIdx]
//    array[startIdx] = endValue
//    array[endIdx] = startValue
    
//    array.remove(at: startIdx)
//    array.insert(endValue, at: startIdx)
//    array.remove(at: endIdx)
//    array.insert(startValue, at: endIdx)
    startIdx += 1
    endIdx -= 1
}

print("Reversed array: \(array)")

// MARK: Find Max and Min values from array

let minMaxArray = [54, 62, 111, 5, 32]

var min = Int.max
//var min = 0
var max = 0

if minMaxArray.count == 1 {
    min = minMaxArray[0]
    max = minMaxArray[0]
}

//else {
//    if minMaxArray[0] < minMaxArray[1] {
//        min = minMaxArray[0]
//        max = minMaxArray[1]
//    } else {
//        min = minMaxArray[1]
//        max = minMaxArray[0]
//    }
//}
for value in minMaxArray {
    if value < min {
        min = value
    } else if value > max {
        max = value
    }
}
//for value in 2...minMaxArray.count-1 {
//    if minMaxArray[value] < min {
//        min = minMaxArray[value]
//    } else if minMaxArray[value] > max {
//        max = minMaxArray[value]
//    }
//}

print("Min:\(min) and Max:\(max)")


func merge(_ nums1: inout [Int], _ nums2: [Int]) {
    var num2Idx = 0
    for (index, element) in nums1.enumerated() {
        if element > nums2[num2Idx] {
            nums1.insert(nums2[num2Idx], at: index)
            num2Idx += 1
        }
    }
    while num2Idx < nums2.count {
        nums1.append(nums2[num2Idx])
        num2Idx += 1

    }
    print(nums1)
}

var nums1 = [1,2,3], nums2 = [2,5,6]
merge(&nums1, nums2)
