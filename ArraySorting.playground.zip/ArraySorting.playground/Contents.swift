import UIKit

var str = "Hello, playground"


//MARK: Bubble sort - o(n^2)

func bubbleSort<T: Comparable>(_ a: inout [T]) {
    let n = a.count
    
    for i in 0..<n {
        for j in 0..<n-i-1 {
            if a[j] > a[j+1] {
                a.swapAt(j, j+1)
            }
        }
    }
    
    print("BubbleSort: \(a)")
}

var bubbleSortArray = [12, 11, 13, 5, 6, 7]
bubbleSort(&bubbleSortArray)

//MARK: Merge sort

func mergeSort<T: Comparable>(_ a: inout [T]) {
    guard a.count > 1 else {
        return
    }
    
    let mid = a.count/2
    var left = Array<T>(a[0..<mid])
    var right = Array<T>(a[mid..<a.count])
    
    mergeSort(&left)
    mergeSort(&right)
    
    var i = 0
    var j = 0
    var k = 0
    
    while i < left.count && j < right.count {
        if left[i] < right[j] {
            a[k] = left[i]
            i += 1
        } else {
            a[k] = right[j]
            j += 1
        }
        
        k += 1
    }
    
    while i < left.count {
        a[k] = left[i]
        i += 1
        k += 1
    }
    
    while j < right.count {
        a[k] = right[j]
        j += 1
        k += 1
    }

    print("Merge sort array: \(a)")
}

var mergeSortArray = [12, 11, 13, 5, 6, 7]
mergeSort(&mergeSortArray)

//MARK: Quick sort

func partition<T: Comparable>(_ a: inout [T], low: Int, high: Int) -> Int {
    print("low: \(low), high: \(high)")

  var i = low
  for j in low..<high where a[j] <= a[high]{
    a.swapAt(i, j)
    i += 1
  }

  a.swapAt(i, high)
    print("Quick Sort process array: \(a)")

  return i
}

func quicksort<T: Comparable>(_ a: inout [T], low: Int, high: Int) {
  if low < high {
    let p = partition(&a, low: low, high: high)
    quicksort(&a, low: low, high: p - 1)
    quicksort(&a, low: p + 1, high: high)
  }
}

var list = [ 10, 0, 3, 9, 2, 14, 27, 26, 1, 5, 8, -1, 40 ]
quicksort(&list, low: 0, high: list.count - 1)

print("Quick Sort array: \(list)")
//func quicksort<T: Comparable>(_ a: [T]) -> [T] {
//  guard a.count > 1 else { return a }
//
//  let pivot = a[a.count/2]
//  let less = a.filter { $0 < pivot }
//  let equal = a.filter { $0 == pivot }
//  let greater = a.filter { $0 > pivot }
//
//  return quicksort(less) + equal + quicksort(greater)
//}

